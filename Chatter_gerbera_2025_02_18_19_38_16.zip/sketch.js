function setup() {
  createCanvas(400, 400);
}

function draw() { 
  background(200);
  circle(200, 200, 300); // rosto
  circle(150, 150, 60); // olho esquerdo
  circle(250, 150, 60); // olho direito
  fill("#e7ebb0");
  circle(200, 200, 300); // rosto
  fill("white")
  circle(150, 150, 60); // olho esquerdo
  circle(250, 150, 60); // olho direito;
  triangle(200, 200, 210, 230, 170, 230
          );
  line (180,100,100,130)
  line (220,100, 300, 130)
   arc(200, 270, 60, 50, 0,3, PI + QUARTER_PI, OPEN);
  
fill("red")
    arc(200, 270, 60, 50, 0,3, PI + QUARTER_PI, OPEN);
  
   
  circle(mouseX, mouseY, 6); // nova pupila esquerda
  
  if (mouseIsPressed) 
     console.log(mouseX, mouseY);
    
  
// código omitido

olhoX = map(mouseX, 0, 400);

circle(mouseX, mouseY, 6); // nova pupila esquerda
  
// código omitido

olhoX = map(mouseX, 0, 400, 130, 170);
olhoY = map(mouseY, 0, 400, 130, 170);



// código omitido
  // código omitido

// circle(150, 150, 10); // pupila esquerda
// circle(250, 150, 10); // pupila direita

olhoX = map(mouseX, 0, 400, 130, 150);
olhoY = map(mouseY, 0, 400, 130, 150);

circle(olhoX, olhoY, 10); // nova pupila esquerda
circle(olhoX + 100, olhoY, 10); //nova pupila direita


  
    }

  

  


